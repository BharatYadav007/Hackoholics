"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion"
import { ChevronDown, Volume2, VolumeX } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export default function Home() {
  const [loading, setLoading] = useState(true)
  const [muted, setMuted] = useState(true)
  const [currentSlide, setCurrentSlide] = useState(0)
  const [activeSection, setActiveSection] = useState("hero")

  const heroRef = useRef(null)
  const storyRef = useRef(null)
  const flavorsRef = useRef(null)
  const storesRef = useRef(null)
  const labRef = useRef(null)
  const pressRef = useRef(null)
  const socialRef = useRef(null)

  const { scrollYProgress } = useScroll()
  const opacity = useTransform(scrollYProgress, [0, 0.2], [1, 0])

  const slides = [
    {
      title: "Gelato, but make it art.",
      subtitle: "Crafted with passion, served with style",
      image: "/placeholder.svg?height=1080&width=1920",
    },
    {
      title: "Tradition meets innovation",
      subtitle: "Where Italian heritage embraces modern creativity",
      image: "/placeholder.svg?height=1080&width=1920",
    },
    {
      title: "Taste the extraordinary",
      subtitle: "Unexpected flavors, unforgettable experiences",
      image: "/placeholder.svg?height=1080&width=1920",
    },
  ]

  const flavors = [
    {
      name: "Pistachio Dream",
      description: "Sicilian pistachios, slow-roasted and blended into our signature cream base",
      image: "/placeholder.svg?height=600&width=600",
      color: "bg-[#9BC88B]",
      category: "classic",
    },
    {
      name: "Dulce de Leche",
      description: "Rich caramelized milk with hints of vanilla and a silky smooth texture",
      image: "/placeholder.svg?height=600&width=600",
      color: "bg-[#D4A373]",
      category: "classic",
    },
    {
      name: "Raspberry Rose",
      description: "Fresh raspberries infused with delicate rose water and a touch of honey",
      image: "/placeholder.svg?height=600&width=600",
      color: "bg-[#E5989B]",
      category: "signature",
    },
    {
      name: "Midnight Chocolate",
      description: "72% single-origin dark chocolate from Ecuador with a hint of sea salt",
      image: "/placeholder.svg?height=600&width=600",
      color: "bg-[#4A4E69]",
      category: "classic",
    },
    {
      name: "Champagne & Strawberries",
      description: "Premium champagne sorbet with fresh strawberry pieces and gold leaf",
      image: "/placeholder.svg?height=600&width=600",
      color: "bg-[#F4ACB7]",
      category: "limited",
    },
    {
      name: "Matcha Ceremony",
      description: "Ceremonial grade Japanese matcha with white chocolate accents",
      image: "/placeholder.svg?height=600&width=600",
      color: "bg-[#90A955]",
      category: "signature",
    },
  ]

  const stores = [
    {
      city: "Buenos Aires",
      address: "Av. Alvear 1750, Recoleta",
      image: "/placeholder.svg?height=800&width=600",
      accent: "border-[#F4ACB7]",
    },
    {
      city: "Miami",
      address: "240 Lincoln Road, Miami Beach",
      image: "/placeholder.svg?height=800&width=600",
      accent: "border-[#9BC88B]",
    },
    {
      city: "Rome",
      address: "Via del Corso 42, Centro Storico",
      image: "/placeholder.svg?height=800&width=600",
      accent: "border-[#D4A373]",
    },
    {
      city: "New York",
      address: "372 West Broadway, SoHo",
      image: "/placeholder.svg?height=800&width=600",
      accent: "border-[#4A4E69]",
    },
  ]

  const press = [
    { name: "Vogue", logo: "/placeholder.svg?height=100&width=200" },
    { name: "GQ", logo: "/placeholder.svg?height=100&width=200" },
    { name: "Food & Wine", logo: "/placeholder.svg?height=100&width=200" },
    { name: "Netflix", logo: "/placeholder.svg?height=100&width=200" },
    { name: "Condé Nast Traveler", logo: "/placeholder.svg?height=100&width=200" },
    { name: "Vanity Fair", logo: "/placeholder.svg?height=100&width=200" },
  ]

  const socialPosts = [
    { image: "/placeholder.svg?height=600&width=600" },
    { image: "/placeholder.svg?height=600&width=600" },
    { image: "/placeholder.svg?height=600&width=600" },
    { image: "/placeholder.svg?height=600&width=600" },
    { image: "/placeholder.svg?height=600&width=600" },
    { image: "/placeholder.svg?height=600&width=600" },
  ]

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false)
    }, 2500)

    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    if (loading) return

    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1))
    }, 6000)

    return () => clearInterval(interval)
  }, [loading, slides.length])

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + window.innerHeight / 2

      const sections = [
        { ref: heroRef, id: "hero" },
        { ref: storyRef, id: "story" },
        { ref: flavorsRef, id: "flavors" },
        { ref: storesRef, id: "stores" },
        { ref: labRef, id: "lab" },
        { ref: pressRef, id: "press" },
        { ref: socialRef, id: "social" },
      ]

      for (const section of sections) {
        if (!section.ref.current) continue

        const element = section.ref.current
        const rect = element.getBoundingClientRect()
        const topPosition = rect.top + window.scrollY
        const bottomPosition = rect.bottom + window.scrollY

        if (scrollPosition >= topPosition && scrollPosition <= bottomPosition) {
          setActiveSection(section.id)
          break
        }
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const toggleMute = () => {
    setMuted(!muted)
  }

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black flex items-center justify-center z-50">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
          className="text-center"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.5, duration: 1.5 }}
          >
            <Image
              src="/placeholder.svg?height=200&width=400"
              alt="Gelato Artisans Logo"
              width={300}
              height={150}
              className="mx-auto"
            />
          </motion.div>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="relative min-h-screen bg-black text-white overflow-hidden">
      <Navbar activeSection={activeSection} />

      {/* Sound Control */}
      <button
        onClick={toggleMute}
        className="fixed bottom-8 left-8 z-50 p-3 rounded-full bg-black/30 backdrop-blur-sm hover:bg-black/50 transition-colors"
      >
        {muted ? <VolumeX size={20} /> : <Volume2 size={20} />}
      </button>

      {/* Hero Section */}
      <section ref={heroRef} id="hero" className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-black/40 z-10"></div>
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1 }}
              className="w-full h-full"
            >
              <Image
                src={slides[currentSlide].image || "/placeholder.svg"}
                alt="Gelato"
                fill
                className="object-cover"
                priority
              />
            </motion.div>
          </AnimatePresence>
        </div>

        <motion.div style={{ opacity }} className="absolute inset-0 flex items-center justify-center z-10">
          <div className="text-center max-w-4xl px-4">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentSlide}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.8 }}
              >
                <h1 className="text-5xl md:text-7xl font-serif mb-4 tracking-tight">{slides[currentSlide].title}</h1>
                <p className="text-xl md:text-2xl font-light text-gray-200 mb-8">{slides[currentSlide].subtitle}</p>
              </motion.div>
            </AnimatePresence>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.5, duration: 1 }}>
              <Button
                variant="outline"
                size="lg"
                className="border-white text-white hover:bg-white hover:text-black rounded-none px-8 py-6 text-lg"
              >
                Discover Our World
              </Button>
            </motion.div>
          </div>
        </motion.div>

        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-col items-center z-10">
          <span className="text-xs tracking-widest mb-2">SCROLL</span>
          <motion.div animate={{ y: [0, 10, 0] }} transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5 }}>
            <ChevronDown size={20} />
          </motion.div>
        </div>
      </section>

      {/* Our Story Section */}
      <section ref={storyRef} id="story" className="py-24 md:py-32">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true, margin: "-100px" }}
            >
              <div className="relative aspect-[3/4] w-full">
                <Image src="/placeholder.svg?height=900&width=600" alt="Our story" fill className="object-cover" />
              </div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true, margin: "-100px" }}
              className="max-w-xl"
            >
              <h2 className="text-3xl md:text-5xl font-serif mb-8">Our Story</h2>
              <p className="text-lg text-gray-300 mb-6 leading-relaxed">
                Founded in 2010 by Master Gelato Artisan Marco Rossi, our journey began with a simple mission: to create
                the most exquisite gelato using traditional Italian methods and the finest ingredients from around the
                world.
              </p>
              <p className="text-lg text-gray-300 mb-8 leading-relaxed">
                What began as a small artisanal shop has grown into an international brand, but our commitment to
                quality and tradition remains unchanged. Every flavor is still crafted in small batches, ensuring the
                perfect texture and depth of flavor that has become our signature.
              </p>
              <Button
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-black rounded-none px-6"
              >
                Read More
              </Button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Flavors Section */}
      <section ref={flavorsRef} id="flavors" className="py-24 md:py-32 bg-neutral-950">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-serif mb-4">Our Signature Flavors</h2>
            <p className="text-lg text-gray-300 max-w-3xl mx-auto">
              Discover our collection of artisanal gelato, crafted with premium ingredients and inspired by both Italian
              tradition and contemporary culinary innovation.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {flavors.map((flavor, index) => (
              <motion.div
                key={flavor.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true, margin: "-100px" }}
                className="group cursor-pointer"
              >
                <div className="relative aspect-square overflow-hidden mb-6">
                  <div className={cn("absolute inset-0", flavor.color, "opacity-20")}></div>
                  <Image
                    src={flavor.image || "/placeholder.svg"}
                    alt={flavor.name}
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-110 mix-blend-luminosity group-hover:mix-blend-normal"
                  />
                  <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <span className="px-4 py-2 border border-white text-sm tracking-wider">DISCOVER</span>
                  </div>
                </div>
                <h3 className="text-2xl font-serif mb-2">{flavor.name}</h3>
                <p className="text-gray-400">{flavor.description}</p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            viewport={{ once: true, margin: "-100px" }}
            className="text-center mt-16"
          >
            <Button
              variant="outline"
              size="lg"
              className="border-white text-white hover:bg-white hover:text-black rounded-none px-8"
            >
              View All Flavors
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Stores Section */}
      <section ref={storesRef} id="stores" className="py-24 md:py-32">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-serif mb-4">Our Flagship Stores</h2>
            <p className="text-lg text-gray-300 max-w-3xl mx-auto">
              Visit one of our elegant boutiques around the world, each designed as a unique sensory experience that
              reflects the culture and spirit of its location.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {stores.map((store, index) => (
              <motion.div
                key={store.city}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true, margin: "-100px" }}
                className="group cursor-pointer"
              >
                <div className={cn("relative aspect-[3/4] overflow-hidden mb-6 border-b-4", store.accent)}>
                  <Image
                    src={store.image || "/placeholder.svg"}
                    alt={store.city}
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent"></div>
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-left">
                    <h3 className="text-2xl font-serif mb-1">{store.city}</h3>
                    <p className="text-gray-300">{store.address}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            viewport={{ once: true, margin: "-100px" }}
            className="text-center mt-16"
          >
            <Button
              variant="outline"
              size="lg"
              className="border-white text-white hover:bg-white hover:text-black rounded-none px-8"
            >
              Find a Store
            </Button>
          </motion.div>
        </div>
      </section>

      {/* The Lab Section */}
      <section ref={labRef} id="lab" className="py-24 md:py-32 bg-neutral-950">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true, margin: "-100px" }}
              className="order-2 lg:order-1 max-w-xl"
            >
              <h2 className="text-3xl md:text-5xl font-serif mb-8">The Lab</h2>
              <p className="text-lg text-gray-300 mb-6 leading-relaxed">
                Welcome to our creative workshop, where tradition meets innovation. In The Lab, our master gelato
                artisans experiment with unexpected flavor combinations, textures, and presentations to push the
                boundaries of what gelato can be.
              </p>
              <p className="text-lg text-gray-300 mb-8 leading-relaxed">
                From collaborations with renowned chefs to limited-edition collections inspired by art, fashion, and pop
                culture, The Lab is where our most daring and avant-garde creations come to life.
              </p>
              <Button
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-black rounded-none px-6"
              >
                Explore The Lab
              </Button>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true, margin: "-100px" }}
              className="order-1 lg:order-2"
            >
              <div className="relative aspect-square w-full">
                <Image src="/placeholder.svg?height=800&width=800" alt="The Lab" fill className="object-cover" />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Press & Collaborations */}
      <section ref={pressRef} id="press" className="py-24 md:py-32">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-serif mb-4">Press & Collaborations</h2>
            <p className="text-lg text-gray-300 max-w-3xl mx-auto">
              Our artisanal approach to gelato has captured the attention of global media and led to exciting
              collaborations with leading brands in fashion, art, and entertainment.
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
            {press.map((item, index) => (
              <motion.div
                key={item.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true, margin: "-100px" }}
                className="group cursor-pointer"
              >
                <div className="relative aspect-[3/2] bg-neutral-900 flex items-center justify-center p-6 transition-all duration-300 group-hover:bg-neutral-800">
                  <Image
                    src={item.logo || "/placeholder.svg"}
                    alt={item.name}
                    width={150}
                    height={75}
                    className="object-contain filter grayscale opacity-70 transition-all duration-300 group-hover:grayscale-0 group-hover:opacity-100"
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Instagram Feed */}
      <section ref={socialRef} id="social" className="py-24 md:py-32 bg-neutral-950">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-5xl font-serif mb-4">Follow Our Journey</h2>
            <p className="text-lg text-gray-300 max-w-3xl mx-auto">
              Join our community on Instagram and share your gelato moments with us using #GelatoArtisans
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {socialPosts.map((post, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true, margin: "-100px" }}
                className="group cursor-pointer"
              >
                <div className="relative aspect-square overflow-hidden">
                  <Image
                    src={post.image || "/placeholder.svg"}
                    alt="Instagram post"
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="w-8 h-8"
                    >
                      <path d="M18 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2z"></path>
                      <circle cx="12" cy="10" r="3"></circle>
                      <path d="M18 10a6 6 0 0 0-12 0"></path>
                    </svg>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            viewport={{ once: true, margin: "-100px" }}
            className="text-center mt-16"
          >
            <Button
              variant="outline"
              size="lg"
              className="border-white text-white hover:bg-white hover:text-black rounded-none px-8"
            >
              Follow Us @GelatoArtisans
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-24 md:py-32 relative">
        <div className="absolute inset-0 z-0">
          <Image
            src="/placeholder.svg?height=1080&width=1920"
            alt="Background"
            fill
            className="object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-black/60"></div>
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, margin: "-100px" }}
            className="max-w-2xl mx-auto text-center"
          >
            <h2 className="text-3xl md:text-5xl font-serif mb-6">Join Our World</h2>
            <p className="text-lg text-gray-300 mb-8">
              Subscribe to our newsletter for exclusive offers, new flavor announcements, and invitations to special
              events.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <input
                type="email"
                placeholder="Your email address"
                className="flex-grow bg-transparent border border-white/50 px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-white"
              />
              <Button className="bg-white text-black hover:bg-gray-200 rounded-none px-8">Subscribe</Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  )
}
